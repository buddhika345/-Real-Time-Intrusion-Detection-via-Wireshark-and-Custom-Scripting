import subprocess

suspicious_ips = {}
threshold = 5
interface = "eth1"

print("[*] Starting Real-Time Intrusion Detection...")

cmd = [
    "tshark", "-i", interface, "-l", "-T", "fields",
    "-e", "ip.src", "-e", "ip.dst",
    "-e", "tcp.flags.syn", "-e", "tcp.flags.ack"
]

process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)

try:
    for line in process.stdout:
        line = line.decode().strip()
        if not line:
            continue

        print(f"[DEBUG] Packet: {line}")  # Show live packet info

        fields = line.split("\t")
        if len(fields) < 4:
            continue

        src_ip, dst_ip, syn_flag, ack_flag = fields

        if syn_flag == "1" and ack_flag != "1":
            suspicious_ips[src_ip] = suspicious_ips.get(src_ip, 0) + 1
            print(f"[DEBUG] SYN Detected from {src_ip} (Count: {suspicious_ips[src_ip]})")

            if suspicious_ips[src_ip] == threshold:
                print(f"[ALERT] SYN Scan Detected from {src_ip}")

except KeyboardInterrupt:
    print("\n[+] IDS Stopped.")
    process.terminate()


